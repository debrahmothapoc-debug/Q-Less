# 🚌 Q-Less — Backend API

> Skip the queue. Book your taxi seat in advance.

Built with **Node.js + Express + PostgreSQL** for the South African taxi industry.

---

## 🗂 Project Structure

```
qless-backend/
├── src/
│   ├── server.js              # Entry point
│   ├── db/
│   │   ├── index.js           # PostgreSQL connection pool
│   │   ├── migrate.js         # Creates all tables
│   │   └── seed.js            # Seeds SA routes, drivers & time slots
│   ├── middleware/
│   │   ├── auth.js            # JWT authentication & role guard
│   │   └── errorHandler.js    # Validation & global error handling
│   ├── routes/
│   │   ├── auth.js            # Register, login, /me
│   │   ├── routes.js          # Taxi routes & time slots
│   │   ├── bookings.js        # Create, view, cancel bookings
│   │   └── driver.js          # Driver dashboard & passenger manifest
│   └── services/
│       └── sms.js             # Africa's Talking SMS service
├── .env.example
├── package.json
└── README.md
```

---

## ⚡ Quick Start

### 1. Prerequisites

- [Node.js](https://nodejs.org) v18+
- [PostgreSQL](https://www.postgresql.org) v14+

### 2. Install dependencies

```bash
cd qless-backend
npm install
```

### 3. Set up environment variables

```bash
cp .env.example .env
# Open .env and fill in your values
```

### 4. Create the PostgreSQL database

```sql
-- In psql or pgAdmin:
CREATE DATABASE qless_db;
CREATE USER qless_user WITH PASSWORD 'your_strong_password';
GRANT ALL PRIVILEGES ON DATABASE qless_db TO qless_user;
```

### 5. Run migrations (creates all tables)

```bash
npm run db:migrate
```

### 6. Seed initial data (routes, drivers, time slots)

```bash
npm run db:seed
```

### 7. Start the server

```bash
# Production
npm start

# Development (auto-restart on file changes)
npm run dev
```

Server runs on **http://localhost:5000**

---

## 📡 API Reference

### Auth

| Method | Endpoint | Description | Auth |
|--------|----------|-------------|------|
| POST | `/api/auth/register` | Register commuter or driver | No |
| POST | `/api/auth/login` | Login → returns JWT | No |
| GET | `/api/auth/me` | Get current user | JWT |

**Register body:**
```json
{
  "name": "Nomsa Dlamini",
  "phone": "0721234567",
  "password": "MyPass123",
  "role": "commuter"
}
```

**Login body:**
```json
{ "phone": "0721234567", "password": "MyPass123" }
```

---

### Routes

| Method | Endpoint | Description | Auth |
|--------|----------|-------------|------|
| GET | `/api/routes` | All active routes with driver info | No |
| GET | `/api/routes/:id/slots?date=YYYY-MM-DD` | Time slots + availability | No |

---

### Bookings

| Method | Endpoint | Description | Auth |
|--------|----------|-------------|------|
| POST | `/api/bookings` | Create booking (guest or logged-in) | Optional |
| GET | `/api/bookings/my` | My bookings | JWT (commuter) |
| DELETE | `/api/bookings/:id` | Cancel booking | JWT |

**Create booking body (guest):**
```json
{
  "time_slot_id": "uuid-of-slot",
  "seats": 2,
  "name": "Nomsa Dlamini",
  "phone": "0721234567"
}
```

**Create booking body (logged-in):**
```json
{
  "time_slot_id": "uuid-of-slot",
  "seats": 2
}
```

---

### Driver

> All driver routes require `Authorization: Bearer <token>` with a driver account.

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/driver/dashboard` | Stats + all today's slots |
| GET | `/api/driver/slots/:slotId/passengers` | Passenger manifest |
| PATCH | `/api/driver/bookings/:bookingId/board` | Mark passenger as boarded |

---

## 🔐 Authentication

All protected routes require:
```
Authorization: Bearer <jwt_token>
```

Tokens expire after **7 days** (configurable via `JWT_EXPIRES_IN`).

---

## 📱 SMS (Africa's Talking)

1. Sign up free at [africastalking.com](https://africastalking.com)
2. In sandbox mode, messages go to their **simulator** (free, no real SMS)
3. For production, add your API key and real username to `.env`

Install the package:
```bash
npm install africastalking
```

---

## 🗄 Database Schema

```
users         id, name, phone, password_hash, role, is_active
routes        id, from_place, to_place, duration_min, fare_rands
drivers       id, user_id → users, route_id → routes, taxi_plate, capacity, rating
time_slots    id, route_id, driver_id, departure_time, slot_date, capacity
bookings      id, booking_ref, user_id, time_slot_id, seats, status, sms_sent
```

---

## 🚀 Deployment (Render / Railway)

Both Render and Railway offer **free PostgreSQL** and Node.js hosting perfect for a South African startup.

**Render:**
1. Push code to GitHub
2. New Web Service → connect repo
3. Build command: `npm install`
4. Start command: `npm start`
5. Add environment variables in the dashboard

**Railway:**
1. `railway init` → `railway up`
2. Add a PostgreSQL plugin
3. Set env vars via `railway variables`

---

## 👤 Demo Credentials (after seeding)

| Role | Phone | Password |
|------|-------|----------|
| Commuter | 0720000001 | Commuter@123 |
| Driver | 0711000001 | Driver@123 |
